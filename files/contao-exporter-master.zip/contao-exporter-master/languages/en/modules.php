<?php

/**
 * Frontend
 */
$GLOBALS['TL_LANG']['FMD']['exporter'] = 'Exporter';
$GLOBALS['TL_LANG']['FMD']['frontendExporter'] = ['Frontend Exporter', 'Allows the usage of export configs in the frontend'];


/**
 * Backend
 */
$GLOBALS['TL_LANG']['MOD']['exporter'] = ['Exporter', 'Alows the configuration of exports callable by global operations.'];
