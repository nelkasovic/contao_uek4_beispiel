<?php

/**
 * Frontend
 */
$GLOBALS['TL_LANG']['FMD']['exporter'] = 'Exporter';
$GLOBALS['TL_LANG']['FMD']['frontendExporter'] = ['Frontend Exporter', 'Erlaubt die Benutzung von Exportkonfigurationen im Frontend'];


/**
 * Backend
 */
$GLOBALS['TL_LANG']['MOD']['exporter'] = ['Exporter', 'Erlaubt das Konfigurieren von Exporten, welche über globale Operationen ausgelöst werden können.'];
