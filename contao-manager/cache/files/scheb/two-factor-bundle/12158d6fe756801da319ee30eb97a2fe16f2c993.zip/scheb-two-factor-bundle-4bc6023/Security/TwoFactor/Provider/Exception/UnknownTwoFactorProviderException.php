<?php

namespace Scheb\TwoFactorBundle\Security\TwoFactor\Provider\Exception;

class UnknownTwoFactorProviderException extends \InvalidArgumentException
{
}
