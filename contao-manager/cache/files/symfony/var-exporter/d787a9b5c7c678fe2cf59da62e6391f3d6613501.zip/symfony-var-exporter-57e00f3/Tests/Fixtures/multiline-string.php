<?php

return [
    "\0\0\r\n"
        .'A' => 'B'."\r"
        .'C'."\n"
        ."\n",
];
