<?php

return [
    123,
    [
        'abc',
    ],
];
