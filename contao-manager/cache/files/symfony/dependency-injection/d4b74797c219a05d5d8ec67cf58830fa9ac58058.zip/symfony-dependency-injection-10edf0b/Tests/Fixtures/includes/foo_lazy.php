<?php

namespace Bar;

class FooLazyClass
{
}
