<?php

namespace Symfony\Component\DependencyInjection\Tests\Fixtures\includes\HotPath;

class P1 implements I1
{
}
