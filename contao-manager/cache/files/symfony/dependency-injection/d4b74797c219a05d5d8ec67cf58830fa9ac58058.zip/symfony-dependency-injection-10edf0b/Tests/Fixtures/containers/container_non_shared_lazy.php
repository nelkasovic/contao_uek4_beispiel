<?php

use Symfony\Component\DependencyInjection\ContainerBuilder;

return new ContainerBuilder();
