<?php

namespace Symfony\Bundle\FrameworkBundle\Tests\Fixtures;

class DeclaredClass
{
}
