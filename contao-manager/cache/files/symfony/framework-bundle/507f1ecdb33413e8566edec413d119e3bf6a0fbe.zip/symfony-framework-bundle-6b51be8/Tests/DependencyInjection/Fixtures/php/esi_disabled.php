<?php

$container->loadFromExtension('framework', [
    'esi' => [
        'enabled' => false,
    ],
]);
