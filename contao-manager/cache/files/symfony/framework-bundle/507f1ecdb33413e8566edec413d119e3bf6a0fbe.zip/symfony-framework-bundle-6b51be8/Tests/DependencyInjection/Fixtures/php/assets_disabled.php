<?php

$container->loadFromExtension('framework', [
    'assets' => [
        'enabled' => false,
    ],
]);
