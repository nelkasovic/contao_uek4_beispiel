<?php

$container->loadFromExtension('framework', [
    'property_info' => [
        'enabled' => true,
    ],
]);
