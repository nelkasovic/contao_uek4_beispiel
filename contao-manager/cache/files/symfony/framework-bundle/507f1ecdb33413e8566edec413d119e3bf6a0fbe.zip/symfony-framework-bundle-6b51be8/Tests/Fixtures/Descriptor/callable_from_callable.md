
- Type: `closure`
- Name: `__invoke`
- Class: `Symfony\Bundle\FrameworkBundle\Tests\Console\Descriptor\CallableClass`
