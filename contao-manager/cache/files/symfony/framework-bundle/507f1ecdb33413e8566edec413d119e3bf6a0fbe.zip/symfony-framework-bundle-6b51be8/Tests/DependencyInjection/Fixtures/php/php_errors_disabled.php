<?php

$container->loadFromExtension('framework', [
    'php_errors' => [
        'log' => false,
        'throw' => false,
    ],
]);
