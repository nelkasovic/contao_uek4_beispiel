<?php

$container->loadFromExtension('framework', [
    'php_errors' => [
        'log' => 8,
    ],
]);
