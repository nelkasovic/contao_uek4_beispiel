<?php

$container->loadFromExtension('framework', [
    'validation' => [
        'strict_email' => true,
    ],
]);
