<?php

$container->loadFromExtension('framework', [
    'translator' => [
        'fallbacks' => ['en', 'fr'],
    ],
]);
