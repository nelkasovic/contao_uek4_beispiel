<?php

$container->loadFromExtension('swiftmailer', [
    'transport' => null,
]);
