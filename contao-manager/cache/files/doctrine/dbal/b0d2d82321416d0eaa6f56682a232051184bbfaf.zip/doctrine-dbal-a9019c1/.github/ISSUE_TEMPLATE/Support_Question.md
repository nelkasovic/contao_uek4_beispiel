---
name: ❓ Support Question
about: Have a problem that you can't figure out? 🤔
---

<!-- Fill in the relevant information below to help triage your issue. -->

|    Q        |   A
|------------ | -----
| Version     | x.y.z

<!--
Before asking a question here, please try asking on Gitter or Slack first.
Find out more about Doctrine support channels here: https://www.doctrine-project.org/community/
Keep in mind that GitHub is primarily an issue tracker.
-->

### Support Question

<!-- Describe the issue you are facing here. -->
