<?php

namespace App\ContaoManager;

class Plugin
{
}
