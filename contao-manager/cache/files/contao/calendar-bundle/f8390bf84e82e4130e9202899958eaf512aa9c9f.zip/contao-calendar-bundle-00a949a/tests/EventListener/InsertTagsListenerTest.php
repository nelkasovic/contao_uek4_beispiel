<?php

declare(strict_types=1);

/*
 * This file is part of Contao.
 *
 * (c) Leo Feyer
 *
 * @license LGPL-3.0-or-later
 */

namespace Contao\CalendarBundle\Tests\EventListener;

use Contao\CalendarBundle\EventListener\InsertTagsListener;
use Contao\CalendarEventsModel;
use Contao\CalendarFeedModel;
use Contao\Events;
use Contao\TestCase\ContaoTestCase;

class InsertTagsListenerTest extends ContaoTestCase
{
    public function testReplacesTheCalendarFeedTag(): void
    {
        $properties = [
            'feedBase' => 'http://localhost/',
            'alias' => 'events',
        ];

        $feedModel = $this->mockClassWithProperties(CalendarFeedModel::class, $properties);

        $adapters = [
            CalendarFeedModel::class => $this->mockConfiguredAdapter(['findByPk' => $feedModel]),
        ];

        $framework = $this->mockContaoFramework($adapters);

        $listener = new InsertTagsListener($framework);
        $url = $listener->onReplaceInsertTags('calendar_feed::2', false, null, []);

        $this->assertSame('http://localhost/share/events.xml', $url);
    }

    public function testReplacesTheEventTags(): void
    {
        $properties = [
            'title' => 'The "foobar" event',
            'teaser' => '<p>The annual foobar event.</p>',
        ];

        $eventModel = $this->mockClassWithProperties(CalendarEventsModel::class, $properties);

        $events = $this->mockAdapter(['generateEventUrl']);
        $events
            ->method('generateEventUrl')
            ->willReturnCallback(
                function (CalendarEventsModel $model, bool $absolute): string {
                    if ($absolute) {
                        return 'http://domain.tld/events/the-foobar-event.html';
                    }

                    return 'events/the-foobar-event.html';
                }
            )
        ;

        $adapters = [
            CalendarEventsModel::class => $this->mockConfiguredAdapter(['findByIdOrAlias' => $eventModel]),
            Events::class => $events,
        ];

        $listener = new InsertTagsListener($this->mockContaoFramework($adapters));

        $this->assertSame(
            '<a href="events/the-foobar-event.html" title="The &quot;foobar&quot; event">The "foobar" event</a>',
            $listener->onReplaceInsertTags('event::2', false, null, [])
        );

        $this->assertSame(
            '<a href="events/the-foobar-event.html" title="The &quot;foobar&quot; event">',
            $listener->onReplaceInsertTags('event_open::2', false, null, [])
        );

        $this->assertSame(
            'events/the-foobar-event.html',
            $listener->onReplaceInsertTags('event_url::2', false, null, [])
        );

        $this->assertSame(
            'http://domain.tld/events/the-foobar-event.html',
            $listener->onReplaceInsertTags('event_url::2', false, null, ['absolute'])
        );

        $this->assertSame(
            'The &quot;foobar&quot; event',
            $listener->onReplaceInsertTags('event_title::2', false, null, [])
        );

        $this->assertSame(
            '<p>The annual foobar event.</p>',
            $listener->onReplaceInsertTags('event_teaser::2', false, null, [])
        );
    }

    public function testReturnsFalseIfTheTagIsUnknown(): void
    {
        $listener = new InsertTagsListener($this->mockContaoFramework());

        $this->assertFalse($listener->onReplaceInsertTags('link_url::2', false, null, []));
    }

    public function testReturnsAnEmptyStringIfThereIsNoModel(): void
    {
        $adapters = [
            CalendarEventsModel::class => $this->mockConfiguredAdapter(['findByIdOrAlias' => null]),
            CalendarFeedModel::class => $this->mockConfiguredAdapter(['findByPk' => null]),
        ];

        $listener = new InsertTagsListener($this->mockContaoFramework($adapters));

        $this->assertSame('', $listener->onReplaceInsertTags('calendar_feed::3', false, null, []));
        $this->assertSame('', $listener->onReplaceInsertTags('event_url::3', false, null, []));
    }
}
