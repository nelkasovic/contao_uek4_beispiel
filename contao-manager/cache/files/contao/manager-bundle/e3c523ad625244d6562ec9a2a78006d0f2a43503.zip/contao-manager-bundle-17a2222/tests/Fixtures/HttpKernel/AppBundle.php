<?php

namespace AppBundle;

class AppBundle
{
}
