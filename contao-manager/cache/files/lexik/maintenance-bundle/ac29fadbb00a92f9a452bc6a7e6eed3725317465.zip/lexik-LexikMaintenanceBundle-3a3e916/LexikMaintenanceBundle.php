<?php

namespace Lexik\Bundle\MaintenanceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LexikMaintenanceBundle extends Bundle
{
}
