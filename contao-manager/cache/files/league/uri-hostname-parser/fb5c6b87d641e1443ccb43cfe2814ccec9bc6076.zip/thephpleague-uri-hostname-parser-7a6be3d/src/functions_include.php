<?php

// Don't redefine the functions if included multiple times.
if (!function_exists('League\Uri\resolve_domain')) {
    require __DIR__.'/functions.php';
}
