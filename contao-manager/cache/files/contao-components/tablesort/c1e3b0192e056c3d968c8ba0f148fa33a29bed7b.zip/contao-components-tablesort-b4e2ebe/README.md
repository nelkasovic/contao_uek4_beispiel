Contao tablesort.js
=================

This is the [Contao Open Source CMS][1] tablesort.js script.


[1]: https://contao.org
