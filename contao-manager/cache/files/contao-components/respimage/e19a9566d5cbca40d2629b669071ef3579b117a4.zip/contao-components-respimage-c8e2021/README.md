Respimage.js
============

This is a customized package of the [Respimage.js][1] script to be integrated
in [Contao Open Source CMS][2].


[1]: https://github.com/aFarkas/respimage/
[2]: https://contao.org
