HTML5 Shiv
==========

This is a customized [HTML5 shiv][1] package to be integrated in
[Contao Open Source CMS][2].


[1]: https://github.com/aFarkas/html5shiv
[2]: https://contao.org
