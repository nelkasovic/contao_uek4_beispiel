Tablesorter
===========

This is a customized jQuery [tablesorter][1] distribution to be integrated in
[Contao Open Source CMS][2].


[1]: http://tablesorter.com
[2]: https://contao.org
