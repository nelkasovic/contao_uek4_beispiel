Highlight.js
============

This is a customized [Highlight.js][1] package to be integrated in
[Contao Open Source CMS][2].


[1]: https://highlightjs.org
[2]: https://contao.org
