MediaElement.js
===============

This is a customized package of the [MediaElement.js][1] player to be integrated
in [Contao Open Source CMS][2].


[1]: http://mediaelementjs.com
[2]: https://contao.org
