MooTools
========

This is a customized [MooTools][1] distribution to be integrated in
[Contao Open Source CMS][2].


[1]: http://mootools.net
[2]: https://contao.org
