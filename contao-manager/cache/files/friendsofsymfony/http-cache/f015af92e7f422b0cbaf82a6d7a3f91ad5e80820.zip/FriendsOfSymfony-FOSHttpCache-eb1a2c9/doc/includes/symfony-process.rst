Requires Symfony’s Process component, so make sure to include that in your
project:

.. code-block:: bash

    $ composer require symfony/process
